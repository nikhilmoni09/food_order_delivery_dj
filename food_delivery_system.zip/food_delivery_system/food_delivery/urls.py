from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import AdminViewSet, DeliveryAgentViewSet, CustomerViewSet

router = DefaultRouter()
router.register(r'admin', AdminViewSet)
router.register(r'delivery_agents', DeliveryAgentViewSet)
router.register(r'customers', CustomerViewSet)

urlpatterns = [
    path('api/', include(router.urls)),
]
