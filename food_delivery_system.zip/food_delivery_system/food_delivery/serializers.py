from rest_framework import serializers
from .models import Product, Order, User, DeliveryAgent

class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = ['id', 'name', 'description', 'price', 'image']

class OrderSerializer(serializers.ModelSerializer):
    products = ProductSerializer(many=True)
    
    class Meta:
        model = Order
        fields = ['id', 'customer', 'products', 'total_amount', 'status', 'created_at', 'updated_at', 'otp']

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'role', 'email', 'first_name', 'last_name']

class DeliveryAgentSerializer(serializers.ModelSerializer):
    user = UserSerializer()

    class Meta:
        model = DeliveryAgent
        fields = ['user', 'phone_number']
