from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from .models import Product, Order, User, DeliveryAgent
from .serializers import ProductSerializer, OrderSerializer, UserSerializer, DeliveryAgentSerializer
from rest_framework.decorators import action

class AdminViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        return User.objects.filter(role=User.ADMIN)

    @action(detail=False, methods=['POST'])
    def bulk_upload_products(self, request):
        # Handle bulk upload of products
        pass

    # Admin functions for Delivery Agent, Customer Management, etc.


class DeliveryAgentViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        return Order.objects.filter(delivery_agent=self.request.user.delivery_agent)

    @action(detail=True, methods=['POST'])
    def update_status(self, request, pk=None):
        order = self.get_object()
        # Implement logic to update order status (ASSIGNED, DELIVERED, etc.)
        pass


class CustomerViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Order.objects.filter(customer=self.request.user)

    @action(detail=True, methods=['POST'])
    def cancel_order(self, request, pk=None):
        order = self.get_object()
        # Implement logic to cancel order
        pass
